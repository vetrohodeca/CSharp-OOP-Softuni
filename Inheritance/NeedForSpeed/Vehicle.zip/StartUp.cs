﻿using System;

namespace NeedForSpeed
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Vehicle Vehicle = new Vehicle(60, 5);
        }
    }
}
