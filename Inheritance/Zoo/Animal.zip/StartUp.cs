﻿using System;

namespace Zoo
{
    public class StartUp
    {
         static void Main(string[] args)
        {
            Gorilla gorilla = new Gorilla(" Pesho");
            Console.WriteLine(gorilla) ;
        }
    }
}
